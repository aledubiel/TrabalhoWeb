<div class="box-content">
    <h2><i class="fas fa-edit"></i> Adicionar Slide</h2>

    <form method="post" enctype="multipart/form-data">
        <?php
            if(isset($_POST['acao'])){
                $nome = $_POST['nome'];      
                $imagem = $_FILES['imagem'];             
            
            if($nome == ''){
                Painel::messageToUser('erro', 'Preencha o nome do Slide');
            }else{
                if(Painel::validImage($imagem) == false){
                    Painel::messageToUser('erro', 'Formato de Imagem permitido (jpeg, jpg ou png)');
                } else{                    
                    $imagem = Painel::uploudFile($imagem);
                    $arr = ['nome'=>$nome, 'slide'=>$imagem, 'order_id'=>'0', 'nomeTabela'=>'tb_admin.slides'];
                    Painel::insert($arr);
                    Painel::messageToUser('sucesso', 'O cadastro do Slide foi realizado com sucesso');
                }
            }
        }
        ?>

        <div class="form-group">
            <label for="nome">Nome do Slide: </label>
            <input type="text" name="nome" required>
        </div>

        <div class="form-group">
            <label for="imagem">Imagem: </label>
            <input type="file" name="imagem">
        </div>
        <div class="form-group">
            <input type="submit" name="acao" value="Adicionar">
        </div>
    </form>

</div>