<div class="box-content">
    <?php Painel::messageToUser('erro', 'Você não tem permissão para acessar a página') ?>
</div>