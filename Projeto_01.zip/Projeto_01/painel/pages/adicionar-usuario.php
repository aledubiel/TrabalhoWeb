<div class="box-content">
    <h2><i class="fas fa-edit"></i> Adicionar Usuário</h2>

    <form method="post" enctype="multipart/form-data">
        <?php
            if(isset($_POST['acao'])){
                
            }
        ?>
    </form>

</div>