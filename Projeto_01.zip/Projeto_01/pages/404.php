<section class="erro-404">
    <div class="center">
        <h2><i class="fa-solid fa-bomb"></i>A página não existe!</h2>
        <p>Deseja voltar para a <a href="<?php echo INCLUDE_PATH;?>">página inicial</a>?</p>
    </div>
</section>